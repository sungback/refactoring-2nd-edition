string_list = ['hello', 'my', 'name', 'is', 'startcoding']

for string in string_list:
    print(string)

# 리스트 extend
a = [1, 2, 3, 4, 5]
b = [6, 7, 8, 9]
a.extend(b)
print( a )

# 리스트 append
a = [1, 2, 3, 4, 5]
a.append(6)
print( a )

# end
