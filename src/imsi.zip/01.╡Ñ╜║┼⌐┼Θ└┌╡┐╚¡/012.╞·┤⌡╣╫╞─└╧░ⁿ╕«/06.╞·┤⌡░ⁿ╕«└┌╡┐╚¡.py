# C:/Dn 폴더에 있는 이미지(.jpg, .png)들을 C:/Dn/images 폴더를 만들고 이동시키기

import os, shutil, glob

# 정리할 폴더 경로
target_folder = './Dn'

# 1. images 폴더가 없다면 만들기 : 이미지를 저장할 경로
img_folder = os.path.join(target_folder, 'images')

if not os.path.exists(img_folder):
    os.mkdir(img_folder)

# 2. 다운로드 폴더에 있는 파일 목록 확인 (.jpg, .png)
# file_list = [] 안에 모든 이미지 파일 경로 추가하기

# 정리할 확장자
ext_list = ['jpg', 'png']

file_list = []
for ext in ext_list:
    a = glob.glob(f'{target_folder}/*.{ext}')
    file_list.extend(a)

print(file_list)

# 3. 파일을 이동시키기
for file in file_list:
    shutil.move(file, img_folder)

# end
