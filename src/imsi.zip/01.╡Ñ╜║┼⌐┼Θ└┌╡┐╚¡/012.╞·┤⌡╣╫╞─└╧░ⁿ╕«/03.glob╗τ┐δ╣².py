# glob pattern 매칭 기법
# 패턴에 맞는 파일을 찾을 때 사용

import glob

print( glob.glob('테스트1/2023-02-06 data1.txt') )

# ? 기호
# 문자의 종류와 상관없이 정확히 한글자와 매칭
print( glob.glob('테스트1/2023-02-06 data?.txt') )

print( glob.glob('테스트1/2023-02-06 data??.txt') )

# * 기호
# 길이와 상관없이 모든 문자열과 매칭
print( glob.glob('테스트1/2023-02-06 *.txt') )

# ** 기호
# 현재 디렉토리 뿐만 아니라 하위 디렉토리 모두 탐색
# recursive = True 옵션을 줘야 함
print( glob.glob('테스트1/**/*.txt', recursive=True) )

# end
