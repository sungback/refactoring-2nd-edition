for i in range(5):
    print(i)

for i in range(1, 6):
    print(i)

# 파일 입출력
f = open('test.txt', 'w')
f.write('hi')
f.close()

# 파일 100개 만들기
for i in range(1, 101):
    f = open(f'테스트1/2023-02-06 데이터{i}.txt', 'w')
    f.write(f'data{i}')
    f.close()

# 파일 이름 변경
import os

# os.rename('수정전 경로', '수정후 경로')
# 2023-02-06 데이터1.txt -> 2023-02-06 data1.txt 수정

for i in range(1, 101):
    path1 = f'테스트1/2023-02-06 데이터{i}.txt'
    path2 = f'테스트1/2023-02-06 data{i}.txt'
    os.rename(path1, path2)

# end