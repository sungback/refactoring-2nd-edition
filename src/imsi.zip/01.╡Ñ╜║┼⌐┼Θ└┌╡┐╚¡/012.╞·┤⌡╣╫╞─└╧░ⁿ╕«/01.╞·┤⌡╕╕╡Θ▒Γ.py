import os

# 상대 경로 이용
try:
    os.mkdir('테스트1')
except Exception as e:
    print(e) # [WinError 183] 파일이 이미 있으므로 만들 수 없습니다: '테스트1'

# 상대 경로 이용 2
try:
    os.mkdir('테스트1/테스트2')
except Exception as e:
    print(e) # [WinError 183] 파일이 이미 있으므로 만들 수 없습니다: '테스트1/테스트2'

# 상대 경로 이용 3
try:
    os.mkdir('../테스트3')
except Exception as e:
    print(e) # [WinError 183] 파일이 이미 있으므로 만들 수 없습니다: '../테스트3'

# 절대 경로 이용
try:
    os.makedirs('C:/samsung_auto2/01.데스크톱자동화/테스트4')
except Exception as e:
    print(e) # [WinError 183] 파일이 이미 있으므로 만들 수 없습니다: 'C:/samsung_auto2/01.데스크톱자동화/테스트4'

# 폴더나 파일이 있는 확인
print( os.path.exists('C:/samsung_auto2/01.데스크톱자동화/테스트4') ) # True

# 논리형 자료형 (Boolean, Bool)
True, False

# 폴더가 없을 때만 만들기
if not os.path.exists('C:/samsung_auto2/01.데스크톱자동화/테스트4'):
    os.mkdir('C:/samsung_auto2/01.데스크톱자동화/테스트4')

# 조건문
age = 20
if age > 19:
    print("어른입니다.")
    print("입장하세요.")
else:
    print("미성년자입니다.")
    print("퇴장하세요.")

# 폴더 내 파일 목록

# "01.마우스키보드" 폴더 파일목록
print( os.listdir('../01.마우스키보드/') )

