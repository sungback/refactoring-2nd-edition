import shutil

# 폴더 이동
shutil.move('../테스트3', './')

shutil.move('../테스트4', './')

# 파일 이동
# shutil.move('파일경로', '폴더경로')
shutil.move('test.txt', '테스트3')

# 파일 복사
shutil.copy('테스트3/test.txt', '테스트4')

# 폴더 복사
from distutils.dir_util import copy_tree

copy_tree('테스트3', '테스트4')

# end
