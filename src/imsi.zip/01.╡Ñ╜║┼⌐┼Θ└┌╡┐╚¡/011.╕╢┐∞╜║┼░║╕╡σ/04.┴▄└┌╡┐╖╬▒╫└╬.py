import pyautogui

pyautogui.alert(text='프로그램 실행', title='알림', button='확인')

# 줌 아이콘으로 마우스 이동
pyautogui.moveTo(51, 643, 2)
pyautogui.doubleClick() # 더블 클릭 해서 실행

# 로그인 버튼으로 이동
pyautogui.moveTo(x=1314, y=858, duration=2)
pyautogui.click()

# 아이디 입력
pyautogui.write('test@naver.com', interval=0.15)
pyautogui.press('tab')
pyautogui.write('12345', interval=0.15)
pyautogui.press('enter')

# 정리
# pyautogui 라이브러리를 이용하면 마우스, 키보드 자동화 할 수 있다.

# 단점
# 1. 화면 좌표가 바뀌면 동작을 하지 않는다
# 2. 제어권 넘겨 주기 때문에, 동시에 다른 작업 불가능

# 클릭이 안될 때
# -> 관리자 권한을 부여하기
