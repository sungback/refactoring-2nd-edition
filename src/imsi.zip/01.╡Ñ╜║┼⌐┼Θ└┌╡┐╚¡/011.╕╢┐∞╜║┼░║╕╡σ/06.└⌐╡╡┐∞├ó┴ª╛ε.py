# 참고문서 - 나도코딩 유튜브

import pyautogui

# 현재 활성화 된 윈도우
window = pyautogui.getActiveWindow()
print( window ) # <Win32Window left="-8", top="-8", width="1936", height="1056", title="day1-6.py - test_ds - Visual Studio Code">

# 윈도우의 제목
print( window.title ) # day1-6.py - test_ds - Visual Studio Code

# 윈도우 좌표
print( window.left, window.top, window.right, window.bottom )

# 윈도우 창을 기준으로 좌표 설정 가능
pyautogui.click(window.left + 40, window.bottom - 50)

# 모든 창의 제목 가져오기
print( pyautogui.getAllTitles() ) # ['Epic Pen Content Surface: \\\\.\\DISPLAY4', 'Epic Pen Toolbar', 'Epic Pen Content Surface: \\\\.\\DISPLAY1', 'day1-6.py - test_ds - Visual Studio Code', '06.윈도우창제어 - Jupyter Notebook - Chrome', '*제목 없음 - Windows 메모장', 'Anaconda Prompt (anaconda3)', '설정', '설정', '사진', '사진', 'Microsoft Store', '', 'Microsoft Store', 'Microsoft Text Input Application', 'Windows 셸 환경 호스트', '', '', '', '', '', 'Jupyter Notebook (anaconda3)', 'Q-Dir 11.21', 'Program Manager']


""" 아래는 jupyter 크롬에서 테스트해야 함! """
# 제목에 특정 단어를 포함하는 윈도우 (리스트로 반환)
# pyautogui.getWindowsWithTitle("chrome")

# window = pyautogui.getWindowsWithTitle("chrome")[0]
# if window.isActive == False:
#     window.activate() # 활성화

# if window.isMaximized == False:
#     window.maximize() # 최대화

# if window.isMinimized == False:
#     window.minimize() # 최소화

# # 창 닫기
# window.close()

# 문제
# 1. 그림판 실행 및 최대화하기 -> 2초 멈춤
# 2. 원하는 도형을 찾아 아무 곳에다가 그리기 -> 2초 멈춤
# 3. 그림판 종료, 저장하지 않음을 선택

# end
