import pyautogui

# 알림창
pyautogui.alert(text='이 메시지는 3초 뒤', title='알림', button='확인')

# 확인창
pyautogui.confirm(text='이 컴퓨터는 악성코드에 감염', title='경고', buttons=['OK', 'Cancel'])

# 입력창
pyautogui.prompt(text='키워드를 입력하세요', title='입력')

# end
