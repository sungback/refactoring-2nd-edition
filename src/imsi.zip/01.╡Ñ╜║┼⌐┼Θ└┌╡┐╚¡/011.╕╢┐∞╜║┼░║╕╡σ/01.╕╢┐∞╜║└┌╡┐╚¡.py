# pip install pyautogui

import pyautogui

# 1. 화면 크기 출력
print( pyautogui.size() ) # Size(width=1920, height=1080)

# 2. 마우스 위치 출력
import time

time.sleep(2)
print( pyautogui.position() )

# 3. 마우스 이동
# pyautogui.moveTo(49, 524) # 한번에 이동
pyautogui.moveTo(49, 524, 2) # 2초동안 이동

# 4. 마우스 클릭
pyautogui.moveTo(49, 524, 2)
pyautogui.click()
pyautogui.click(button='right') # 오른쪽 클릭
pyautogui.doubleClick() # 더블 클릭
pyautogui.click(clicks=3, interval=1) # 3번 클릭 1초마다

# 5. 마우스 드래그
# x=1302, y=94 -> x=892, y=101
pyautogui.moveTo(x=1302, y=94, duration=2)
pyautogui.dragTo(x=892, y=101, duration=2)

# 6. 마우스 이동하고 바로 클릭
pyautogui.click(300, 400, duration=1)

# end
