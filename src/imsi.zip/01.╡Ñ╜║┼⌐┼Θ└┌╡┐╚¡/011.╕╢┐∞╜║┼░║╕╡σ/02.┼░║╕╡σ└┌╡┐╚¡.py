import pyautogui
import time

# 1. 키보드 입력 (문자)
time.sleep(2)
pyautogui.write('Hello world!')

pyautogui.write('Hello world!', interval=0.25)

# 2. 키보드 입력 (키)
time.sleep(2)
pyautogui.press('enter')

# 3. 키보드 입력 (여러개 동시에)
time.sleep(2)
pyautogui.hotkey('ctrl', 'c')

# 4. 한글 입력 방법
import pyperclip

time.sleep(2)
pyperclip.copy("점심 맛있게 드세요")
pyautogui.hotkey('ctrl', 'v')

# end
