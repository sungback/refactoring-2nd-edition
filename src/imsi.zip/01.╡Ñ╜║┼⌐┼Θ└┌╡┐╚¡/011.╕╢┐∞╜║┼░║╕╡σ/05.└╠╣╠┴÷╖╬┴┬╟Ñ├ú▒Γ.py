import pyautogui

# 화면 스크린샷 찍기
pyautogui.screenshot('my_screenshot.png')

# 특정 범위 스크린샷 찍기
pyautogui.screenshot('my_screenshot2.png', region=(0, 0, 300, 400))

# 그림판 또는 계산기
# 1. 특정 이미지를 캡쳐해서 저장
# 2. 해당 이미지로 화면의 좌표 찾기

pyautogui.locateCenterOnScreen('square.png')

# 흑백으로 변경 후 비교
pyautogui.locateCenterOnScreen('square.png', grayscale=True)

# 정확성을 낮추고 싶을 때 confidence 값 낮추기
# confidence 옵션은 opencv 설치해 줘야 한다.
# pip install opencv-python

try:
    x, y = pyautogui.locateCenterOnScreen('square.png', grayscale=True, confidence=0.7)
    pyautogui.click(x, y, duration=2)
except Exception as e: # 반환값을 정상적으로 리턴하지 못하는 경우
    print("e:", e) # e: cannot unpack non-iterable NoneType object

# end
