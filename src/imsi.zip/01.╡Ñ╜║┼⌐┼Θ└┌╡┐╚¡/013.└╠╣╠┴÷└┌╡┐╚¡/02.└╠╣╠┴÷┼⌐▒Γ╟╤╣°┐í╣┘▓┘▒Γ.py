# cats 에 있는 이미지 크기 50% 만큼 줄이기
# 줄인 이미지를 cats/resized_images 폴더에 저장

import os, glob
from PIL import Image

# 정리할 폴더
target_folder = 'cats'
destination = os.path.join(target_folder, 'resized_images')

# 폴더가 없다면 만들기
if not os.path.exists(destination):
    os.mkdir(destination)

# 1. listdir 이용하기
file_list = os.listdir(target_folder)

for file in file_list:
    if '.jpg' in file or '.png' in file:
        img = Image.open(os.path.join(target_folder, file))
        width = int(img.width * 0.5)
        height = int(img.height * 0.5)
        resized_img = img.resize((width, height))
        resized_img.save(os.path.join(destination, file))


# 2. glob 이용하기
import os, glob
from PIL import Image

target_folder = 'cats'
destination = os.path.join(target_folder, 'resized_images')

# 폴더가 없다면 만들기
if not os.path.exists(destination):
    os.mkdir(destination)

file_list = glob.glob(f'{target_folder}/*.jpg')

a = glob.glob(f'{target_folder}/*.png')

file_list.extend(a)

for file in file_list:
    img = Image.open(file)
    width = int(img.width * 0.5)
    height = int(img.height * 0.5)
    resized_img = img.resize((width, height))
    resized_img.save(os.path.join(destination, os.path.basename(file)))
