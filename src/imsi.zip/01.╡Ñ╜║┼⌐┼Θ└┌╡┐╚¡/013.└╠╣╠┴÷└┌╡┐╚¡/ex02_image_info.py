import cv2

img = cv2.imread('./input_dir/girl.jpg')

x_pos,y_pos,width,height = cv2.selectROI("location", img, False)
print("x position, y position : ",x_pos, y_pos)
print("width, height : ",width, height)

cv2.destroyAllWindows()

# Select a ROI and then press SPACE or ENTER button!
# Cancel the selection process by pressing c button!
# x position, y position :  326 228
# width, height :  315 92
