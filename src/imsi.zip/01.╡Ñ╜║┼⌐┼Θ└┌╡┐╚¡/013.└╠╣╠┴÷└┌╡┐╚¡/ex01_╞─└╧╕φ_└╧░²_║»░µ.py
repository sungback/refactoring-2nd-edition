# 해당 폴더의 파일을 일련번호를 붙여서 모두 바꾸기
import os
import shutil

path = "./cats/"

folderlist = os.listdir(path)
print(folderlist)

for i, fname in enumerate(folderlist, 1):
    print(f"{fname}을 cat-{i:02d}.jpg로 파일명을 변경합니다.")
    os.rename( path+fname, path+f"cat-{i:02d}.jpg")
