# pip install pillow
import os
from PIL import Image

# 이미지 불러오기
input_dir = "./input_dir/"
my_img = 'girl.jpg'
img = Image.open( input_dir + my_img )

# 객체 (object)
# 변수와 명령어(함수, 메소드)를 같이 가지는 데이터

# 이미지의 크기
print( img.size ) # (952, 672) # 튜플 : 수정이 안되는 리스트
# img.size[0]
print( img.size[1] ) # 641
print( img.width ) # 이미지 너비, 960
print( img.height ) # 이미지 높이, 641

output_dir = "./output_dir/"
if not os.path.exists(output_dir):
    os.mkdir(output_dir)

# 이미지 크기 변경
img_resized = img.resize((320, 200))
img_resized.save(output_dir + '01_girl_resized.jpg')
img_resized.show()

# 이미지 자르기
img_croped = img.crop((0, 0, 600, 400))
img_croped.show()

# 이미지 회전
img_rotated = img.rotate(90)
img_rotated.show()

img_left_right = img.transpose(Image.Transpose.FLIP_LEFT_RIGHT) # 좌우 대칭
img_left_right.show()

img_top_bottom = img.transpose(Image.Transpose.FLIP_TOP_BOTTOM) # 상하 대칭
img_top_bottom.show()

# 이미지 필터
from PIL import ImageFilter

# 블러 방식 3가지
# img.filter(ImageFilter.BLUR) # BLUR 는 convolution matrix을 사용해서 변환
# img.filter(ImageFilter.BoxBlur(10)) # 특정 범위내에서 반경을 바탕으로 흐릿한 값의 정도를 지정할 수 있음
# img.filter(ImageFilter.GaussianBlur(10)) # 가우스 곡선(잡음)을 이용하여 흐림함을 적용

# 이미지 불러오기
image1 = Image.open(input_dir + my_img)
image1.show()

# 이미지 blur 필터 적용
blur1 = image1.filter(ImageFilter.BLUR)
blur1.show()

# BoxBlur 사용
blur2 = image1.filter(ImageFilter.BoxBlur(5))
blur2.show()

# GaussianBlur 사용
blur3 = img.filter(ImageFilter.GaussianBlur(10))
blur3.show()

# 특정 부분만 블러 처리 하기
# 1. 이미지 자르기
# (left, top, right, bottom)
# 좌측상단:left,top, 우측하단:right,bottom
crop_area = ( 320, 220, 650, 500 )
cropped_img = image1.crop( crop_area )

# 2. 자른 이미지를 블러처리
blured_img = cropped_img.filter(ImageFilter.GaussianBlur(10))

# 3. 원본에 블러처리한 이미지를 붙여넣기
image = Image.open(input_dir + my_img)
image.paste(blured_img, crop_area)
image.show()
image.save(output_dir + '02_girl_part_blur.jpg')

# end
