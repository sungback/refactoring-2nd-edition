from PIL import Image, ImageDraw, ImageFont

# 1. 왼쪽 위에 워터마크 넣기
img = Image.open('people.jpg')
# 문자의 폰트 (구글웹폰트 다운로드)
font = ImageFont.truetype('NotoSansKR-Regular.otf', 100)
# 그리기 객체
draw = ImageDraw.Draw(img)
# 80, 80 위치에 작성
draw.text((80, 80), "워터마크", font=font, fill="#ff3")
img.show()
# 저장
img.save("people_watermark1.jpg")


# 2. 오른쪽 아래 워터마크 넣기
img = Image.open('people.jpg')
font = ImageFont.truetype('NotoSansKR-Regular.otf', 100)
draw = ImageDraw.Draw(img)

## DeprecationWarning: textsize is deprecated and will be removed in Pillow 10 (2023-07-01).
## Use textbbox or textlength instead.
# txt_width, txt_height = draw.textsize("워터마크", font)
# txt_width, txt_height # (368, 124)

# 그려질 텍스트 크기
x0, y0, x1, y1 = draw.textbbox((0, 0), "워터마크", font=font) # (0, 33, 368, 124)
txt_width, txt_height = x1, y1

# 텍스트 좌표 위치
x = img.width - txt_width - 80
y = img.height - txt_height - 80
print( x, y ) # (512, 346)

# x , y 위치에 작성
draw.text((x, y), "워터마크", font=font, fill="#ff3")
img.show()
# 저장
img.save("people_watermark2.jpg")

# end
