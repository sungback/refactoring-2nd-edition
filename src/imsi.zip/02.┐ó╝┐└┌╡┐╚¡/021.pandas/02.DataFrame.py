# 2. DataFrame
# 2차원 데이터 (여러개의 Series)
import warnings
warnings.filterwarnings('ignore')
import pandas as pd
from tabulate import tabulate
from pprint import pprint

# 딕셔너리 (key - value 쌍으로 이루어진 자료구조)
data = {
    '이름' : ['진', '뷔', '정국', '슈가', '제이홉', 'RM', '지민'],
    '출생연도' : [1992, 1995, 1997, 1993, 1994, 1994, 1995],
    '출생지' : ['과천', '대구', '부산', '대구', '광주', '서울', '부산'],
    '담당파트' : ['서브보컬', '서브보컬', '메인보컬', '리드래퍼', '메인댄서', '리더', '메인댄서'],
    '체중' : [61, 63, 66, 57, 59, 70, 58]
}
pprint( data, indent=2 )

# 딕셔너리를 통해 데이터프레임 생성
df = pd.DataFrame(data)
print( "df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# index 지정해서 DataFrame 생성
df2 = pd.DataFrame(data, index=['1번', '2번', '3번', '4번', '5번', '6번', '7번'])
print( "df2 -----" )
print( tabulate( df2, headers='keys', tablefmt='psql', showindex=True ) )

# column 을 지정해서 DataFrame 생성
df3 = pd.DataFrame(data, columns=['이름', '담당파트'])
print( "df3 -----" )
print( tabulate( df3, headers='keys', tablefmt='psql', showindex=True ) )

# end
