import warnings
warnings.filterwarnings('ignore')
import pandas as pd
from tab_print import tprint

df = pd.read_excel('member.xlsx', index_col='번호')
tprint(df, "df")

tprint( df[df['출생연도'] >= 1994])

# 담당파트가 메인댄서인 가수의 이름?
tprint( df[df['담당파트'] == '메인댄서']['이름'] )

# end
