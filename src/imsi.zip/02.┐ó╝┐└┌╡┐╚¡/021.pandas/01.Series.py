# pip install pandas

# Pandas
# 파이썬 데이터 분석 라이브러리, 2차원 데이터 처리에 용이
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

# 1. Series
# 1차원 데이터

# 5일간 달리기 거리 데이터 (km)
distance = pd.Series([3.0, 4.2, 6.0, 3.3, 2.0])
print( "distance -----" )
print( distance )
print( "distance[0] -----" )
print( distance[0] ) # 3.0, 1일차 거리
print( "distance[2] -----" )
print( distance[2] ) # 6.0, 3일차 거리

# Series 생성 (Index 지정)
distance2 = pd.Series([3.0, 4.2, 6.0, 3.3, 2.0], index=["Mon", "Tue", "Wed", "Thu", "Fri"])
print( "distance2 -----" )
print( distance2 )

print( "distance2['Mon] -----" )
print( distance2['Mon'] ) # 3.0, index "Mon" 에 해당 되는 데이터

# print( distance2'Sat'] ) # KeyError: 'Sat'

# end
