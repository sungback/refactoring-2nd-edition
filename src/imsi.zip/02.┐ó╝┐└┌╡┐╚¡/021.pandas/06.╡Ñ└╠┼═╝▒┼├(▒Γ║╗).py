import pandas as pd
from tabulate import tabulate
import warnings
warnings.filterwarnings('ignore')

df = pd.read_excel('member.xlsx', index_col='번호')
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# Column 선택 label
print( "df['이름'] -----" )
print( df['이름'] )

# 여러개의 Column 선택
print( "df[['이름', '출생지']] -----" )
print( df[['이름', '출생지']] )

# Column 선택 (정수 index)
print( "df.columns[0] -----" )
print( df.columns[0] )

print( "df.columns[0] -----" )
print( df[df.columns[1]] )

# Q) 1 ~ 4번 까지 출생지 데이터
print( "df.columns[0] -----" )
print( df['출생지'][:4] )

# Q) 1 ~ 3번 이름과 출생지 데이터
print( "df.columns[0] -----" )
print( df[['이름', '출생지']][:3] )

# df[컬럼명] = 데이터
print( "새로운 Column 추가하기 -----" )
df['순서'] = [1, 2, 3, 4, 5, 6, 7]
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

print( "열 삭제 -----" )
df.drop(columns=['순서'], inplace=True)
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# end
