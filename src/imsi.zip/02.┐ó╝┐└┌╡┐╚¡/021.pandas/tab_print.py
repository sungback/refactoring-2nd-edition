import warnings
warnings.filterwarnings('ignore')

import pandas as pd
from tabulate import tabulate

def tprint( df, name=''):
    if name != '':
        print(f"{name} -----")
    print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )
