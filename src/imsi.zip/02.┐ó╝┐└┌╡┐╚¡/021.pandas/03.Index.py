import pandas as pd
from tabulate import tabulate
import warnings
warnings.filterwarnings('ignore')

data = {
    '이름' : ['진', '뷔', '정국', '슈가', '제이홉', 'RM', '지민'],
    '출생연도' : [1992, 1995, 1997, 1993, 1994, 1994, 1995],
    '출생지' : ['과천', '대구', '부산', '대구', '광주', '서울', '부산'],
    '담당파트' : ['서브보컬', '서브보컬', '메인보컬', '리드래퍼', '메인댄서', '리더', '메인댄서'],
    '체중' : [61, 63, 66, 57, 59, 70, 58]
}
df = pd.DataFrame(data, index=['1번', '2번', '3번', '4번', '5번', '6번', '7번'])
print( "df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

print( "df.index -----" )
print( df.index )

# Index 이름 설정
df.index.name = '번호'
print( "df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

df2 = df.reset_index()
print( "df2 -----" )
print( tabulate( df2, headers='keys', tablefmt='psql', showindex=True ) )

df3 = df.reset_index(drop=True)
print( "df3 -----" )
print( tabulate( df3, headers='keys', tablefmt='psql', showindex=True ) )

df.reset_index(drop=True, inplace=True) # 원본을 수정
print( "df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

df.set_index('이름', inplace=True)
print( "df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# index 를 기준으로 정렬
df4 = df.sort_index() # 오름차순 ascending = True (기본값)
print( "오름차순 df4 -----" )
print( tabulate( df4, headers='keys', tablefmt='psql', showindex=True ) )

df5 = df.sort_index(ascending=False) # 내림차순
print( "내림차순 df5 -----" )
print( tabulate( df5, headers='keys', tablefmt='psql', showindex=True ) )

# 컬럼명 수정하기
df.rename(columns={'출생지': '출생지역'}, inplace=True)
print( "컬럼명 수정하기 df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# 인덱스명 수정하기
df.rename(index={'진' : 'JIN'}, inplace=True)
print( "인덱스명 수정하기 df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# Q) 이름을 reset_index로 컬럼으로 변경 후
# 번호 ('1번' ~'7번') 를 인덱스로 부여
df.reset_index(inplace=True)
print( "이름을 reset_index로 컬럼으로 변경 df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

df.index = ['1번', '2번', '3번', '4번', '5번', '6번', '7번']
print( "번호 ('1번' ~'7번') 를 인덱스로 부여 df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

df.index.name = '번호'
print( "인덱스 name을 번호로 df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# end
