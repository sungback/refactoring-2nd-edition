import warnings
warnings.filterwarnings('ignore')

import pandas as pd
from tabulate import tabulate

# loc : location
# 이름(label)을 이용해서 원하는 row 선택 -> column 선택

import pandas as pd
df = pd.read_excel('member.xlsx', index_col='번호')
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

print( "df.loc['7번'] -----" )
print( df.loc['7번'] )

print( "df.loc[['1번', '2번'], '출생지'] -----" )
print( df.loc[['1번', '2번'], '출생지'] )

# 1번 2번의 출생지와 출생연도
df2 = df.loc[['1번', '2번'], ['출생지', '출생연도']]
print( tabulate( df2, headers='keys', tablefmt='psql', showindex=True ) )

# 1번 ~ 4번 이름, 출생연도, 출생지
df3 = df.loc['1번':'4번', '이름':'출생지']
print( tabulate( df3, headers='keys', tablefmt='psql', showindex=True ) )

df4 = df.loc['2번':'6번', ['이름', '체중']]
print( tabulate( df4, headers='keys', tablefmt='psql', showindex=True ) )

df5 = df.loc[['1번', '7번'], ['이름', '담당파트']]
print( tabulate( df5, headers='keys', tablefmt='psql', showindex=True ) )
