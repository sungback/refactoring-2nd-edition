import pandas as pd
from tabulate import tabulate
import warnings
warnings.filterwarnings('ignore')

df = pd.read_excel('member.xlsx', index_col='번호')
print( "df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# 계산 가능한 데이터에 대해 컬럼별로 개수, 평균, 최소, 최대 등을 요약
print( "df.describe() -----" )
print( tabulate( df.describe(), headers='keys', tablefmt='psql', showindex=True ) )

# 데이터 프레임 요약된 정보
print( "df.info() -----" )
print( tabulate( df.info() ) )

# 처음 4개의 row 가져오기, df.head() 디폴트는 5개
print( "df.head(4) -----" )
print( tabulate( df.head(4), headers='keys', tablefmt='psql', showindex=True ) )

# 마지막 5개 row를 가져오기
print( "df.head() -----" )
print( tabulate( df.tail(), headers='keys', tablefmt='psql', showindex=True ) )

print( "df.index -----" )
print( df.index )

print( "df.columns -----" )
print( df.columns )

print( "df.shape -----" )
print( df.shape )

print( "df['체중'] -----" )
print( df['체중'] )

print( "df['체중'].describe() -----" )
print( df['체중'].describe() )

print( "df['체중'].max() -----" )
print( df['체중'].max() )

print( "df['체중'].min() -----" )
print( df['체중'].min() )

print( "df['체중'].sum() -----" )
print( df['체중'].sum() )

# 체중이 큰 순서로 3개
print( "df['체중'].nlargest(3) -----" )
print( df['체중'].nlargest(3) )

print( "df['출생지'].unique() -----" )
print( df['출생지'].unique() )

print( "df['출생지'].nunique() -----" )
print( df['출생지'].nunique() )

# Q) 체중이 작은 순서대로 3명
print( "df['체중'].nsmallest(3).index -----" )
print( df['체중'].nsmallest(3).index )

# Q) 담당파트의 종류는?
print( "df['담당파트'].unique() -----" )
print( df['담당파트'].unique() )

# end
