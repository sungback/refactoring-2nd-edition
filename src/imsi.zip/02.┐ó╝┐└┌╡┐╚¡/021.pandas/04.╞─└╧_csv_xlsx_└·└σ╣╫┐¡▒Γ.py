import pandas as pd
from tabulate import tabulate
import warnings
warnings.filterwarnings('ignore')

data = {
    '이름' : ['진', '뷔', '정국', '슈가', '제이홉', 'RM', '지민'],
    '출생연도' : [1992, 1995, 1997, 1993, 1994, 1994, 1995],
    '출생지' : ['과천', '대구', '부산', '대구', '광주', '서울', '부산'],
    '담당파트' : ['서브보컬', '서브보컬', '메인보컬', '리드래퍼', '메인댄서', '리더', '메인댄서'],
    '체중' : [61, 63, 66, 57, 59, 70, 58]
}
df = pd.DataFrame(data, index=['1번', '2번', '3번', '4번', '5번', '6번', '7번'])
df.index.name = '번호'
print( "df -----" )
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# DataFrame을 csv 저장
df.to_csv('member.csv', encoding='utf-8') # 인코딩 지정, encoding='utf-8-sig'은 다른 운영체제에서 에러

df.to_csv('member2.csv', encoding='utf-8', index=False) # 인덱스 포함 X, encoding='utf-8-sig'

# DataFrame을 excel 로 저장
df.to_excel('member.xlsx')

# csv 파일 열기
df2 = pd.read_csv('member2.csv')
df2
print( "df2 -----" )
print( tabulate( df2, headers='keys', tablefmt='psql', showindex=True ) )

# excel 파일 열기
df3 = pd.read_excel('member.xlsx', index_col='번호')
df3
print( "df3 -----" )
print( tabulate( df3, headers='keys', tablefmt='psql', showindex=True ) )

# end
