# iloc : integer location
# 정수값으로 row 선택 -> column 선택
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
from tabulate import tabulate

df = pd.read_excel('member.xlsx', index_col='번호')
print( tabulate( df, headers='keys', tablefmt='psql', showindex=True ) )

# 0번째 위치의 데이터
print( df.iloc[0] )

# 0 ~ 4번째 데이터
print( df.iloc[0:5] )

# 0번째 위치의 출생연도
print( df.iloc[0, 1] )

# 4번째 위치의 출생지
print( df.iloc[4, 2] )

# 0번째, 2번째 위치의 출생지
print( df.iloc[[0, 2], 2] )

# 0, 2번째 출생지, 담당파트
print( df.iloc[[0, 2], [2, 3]] )

print( df.iloc[0:4, 2:4] )

# end
