import warnings
warnings.filterwarnings('ignore')
import pandas as pd
from tab_print import tprint

df = pd.read_excel('member.xlsx', index_col='번호')
tprint(df, "df")

tprint( df.sort_values('체중') ) # ascending=True 기본값 : 오름차순

tprint( df.sort_values('체중', ascending=False) ) # 내림차순

tprint( df.sort_values(['출생연도', '체중']) )

tprint( df )

# 새로운 row 추가
new_row = {
    '이름' : '지민',
    '출생연도' : 1995,
    '출생지' : '부산',
    '담당파트' : '메인댄서',
    '체중' : 58
}
df2 = pd.DataFrame(new_row, index=['8번'])
df = pd.concat([df, df2])
tprint(df, "df")

df.drop_duplicates(inplace=True)
tprint(df)

new_row = {
    '이름' : '홍길동'
}
df2 = pd.DataFrame(new_row, index=['8번'])
df = pd.concat([df, df2])
tprint(df)

# Nan 을 가지는 행을 버림
tprint( df.dropna() )

tprint( df.dropna(axis=1) ) # 열을 기준으로 삭제

tprint( df.dropna(how='all') )

tprint( df.dropna(subset=['이름', '출생지']) )

# Nan 을 가지는 0으로 대체
tprint( df.fillna(0) )
