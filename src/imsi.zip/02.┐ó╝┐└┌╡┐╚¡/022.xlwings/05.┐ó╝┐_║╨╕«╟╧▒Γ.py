import xlwings as xw
import pandas as pd

# 엑셀 불러오기
wb = xw.Book('./total.xlsx')
# 시트 선택
ws = wb.sheets['Sheet1']

# A1부터 표데이터 읽어 df로 변경
df = ws.range('A1').options(pd.DataFrame, expand='table', index=False).value
df

df[df['제품명'] == '마우스 패드']

# 1. 제품명 종류 확인하기 (unique)
names = df['제품명'].unique()
names

# 2. 시트를 만들고 데이터 복사
for name in names:
    # 시트 추가
    ws_new = wb.sheets.add(name)
    # 데이터 복사
    ws_new.range('A1').options(index=False).value = df[df['제품명'] == name]

wb.save('./total2.xlsx')
xw.apps.active.quit()

# end
