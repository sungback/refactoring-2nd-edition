# pip install xlwings
import xlwings as xw

# 1. 새로운 엑셀 파일 생성
wb = xw.Book()
wb

# 시트 선택
ws = wb.sheets['Sheet1']

# 시트 이름 변경
ws.name = '기계설계팀'

# 엑셀 저장
wb.save('사무직 교육이수현황.xlsx')

# 엑셀 닫기
xw.apps.active.quit()

# 2. 기존에 만들어진 엑셀파일 불러오기
wb = xw.Book('사무직 교육이수현황.xlsx')

# 새로운 시트 생성
wb.sheets.add('기술지원팀')
wb.sheets.add('검사진단팀')
wb.sheets.add('공정자동화팀')

# 시트 삭제
wb.sheets['검사진단팀'].delete()

# 모든 Sheet 다루기
for sheet in wb.sheets:
    print(sheet.name)
    # 자동화 작업

wb.save('사무직 교육이수현황.xlsx')
xw.apps.active.quit()

# end
