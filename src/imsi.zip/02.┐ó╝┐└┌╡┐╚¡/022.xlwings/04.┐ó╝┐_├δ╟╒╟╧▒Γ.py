# (중요) xlwings로 데이터 프레임 만드는 법
import xlwings as xw
import pandas as pd

wb = xw.Book('onlinesale_data/11번가.xlsx')
ws = wb.sheets['data']
df1 = ws.range('A1').options(pd.DataFrame, expand='table', index=False).value
xw.apps.active.quit()
df1

# 쿠팡.xlsx의 데이터를 동일한 방법으로 df2 변수에 저장
wb = xw.Book('onlinesale_data/쿠팡.xlsx')
ws = wb.sheets['data']
df2 = ws.range('A1').options(pd.DataFrame, expand='table', index=False).value
xw.apps.active.quit()
df2

total_df = pd.concat([df1, df2], ignore_index=True) # axis=0 기본값
total_df


import os
import xlwings as xw
import pandas as pd
from time import sleep
# 데이터 폴더 경로
folder_path = './onlinesale_data'

file_list = os.listdir(folder_path)

# 빈 데이터 프레임 생성
total_df = pd.DataFrame()
for file in file_list:
    excel_path = os.path.join(folder_path, file)
    # 엑셀 불러오기
    wb = xw.Book(excel_path)
    # 시트 선택
    ws = wb.sheets['data']
    sleep(2)
    # A1부터 표 데이터를 읽어 데이터프레임으로 변경
    df = ws.range('A1').options(pd.DataFrame, expand='table',
                                index=False).value
    # 데이터 프레임 이어주기
    total_df = pd.concat([total_df, df], ignore_index=True)
    # 엑셀 닫기
    xw.apps.active.quit()

# 합계 파일 저장
total_df.to_excel(f'./total.xlsx', index=False)


# 자동 열 너비 맞추기
wb = xw.Book('./total.xlsx')
ws = wb.sheets['Sheet1']
ws.autofit(axis='columns')  # myrange.columns.autofit()
wb.save('./total.xlsx')
xw.apps.active.quit()

# end
