# 1. taxbill_data 폴더의 파일 리스트 가져오기
import os
import xlwings as xw

# 폴더 경로
folder_path = './taxbill_data'
file_list = os.listdir(folder_path)
file_list

for file in file_list:
    excel_path = os.path.join(folder_path, file)
    # 기존 엑셀 파일 불러오기
    wb = xw.Book(excel_path)
    # 특정 시트 선택
    ws = wb.sheets['자료입력페이지']
    # 데이터 수정
    ws.range('C14').value = '2023-02-01'
    # 엑셀 저장
    wb.save(excel_path)
    xw.apps.active.quit()

# end
