import xlwings as xw

wb = xw.Book('사무직 교육이수현황.xlsx')
ws = wb.sheets['기계설계팀']

# 데이터 1개 입력
ws.range('A1').value = '성명'

ws.range('B1').value = '1월'
ws.range('A2').value = '정우성'
ws.range('B2').value = 8

# 데이터 여러개 입력
ws.range('A3').value = ['유연석', 0]

ws.range('A4').value = [['조진웅', 14.5], ['박보검', 3]]

# 데이터 세로로 입력
ws.range('A6').options(transpose=True).value = ['김슬기', '주현영']

ws.range('B6').options(transpose=True).value = [12, 5]

# 마지막 행 번호
max_row = ws.range('B1').end('down').row
print( max_row )

# 수식도 입력 가능
ws.range('A8').value = '합계'
ws.range(f'B{max_row + 1}').value = f'=SUM(B2:B{max_row})'

# 마지막 열 번호
max_col = ws.range('A1').end('right').column
max_col

# 셀을 확장하여 선택하기
ws.range('A2').expand('down').value

ws.range('A2').expand('right').value

ws.range('A2').expand().value # 'table'이 기본값

# 1행에 빈 행 삽입
ws.range('1:1').insert()

# A열에 빈 열 삽입
ws.range('A:A').insert()

# 셀 병합
ws.range('A1:E1').merge()

# 폰트 & 정렬
ws.range('A1').value = "기계설계팀 교육이수 현황"
ws.range('A1').font.bold = True
ws.range('A1').font.size = 16
ws.range('A1').font.color = (252, 186, 3)
# 정렬 기본값 : 1(왼쪽), 3(중앙), 4(오른쪽)
ws.range('A1').api.HorizontalAlignment = 3

wb.save('사무직 교육이수현황.xlsx')
xw.apps.active.quit()

from time import sleep
sleep(3)

import xlwings as xw

wb = xw.Book('사무직 교육이수현황.xlsx')
ws = wb.sheets['기계설계팀']

# offset 특정 셀에서 얼마나 떨어졌나
ws.range('B3').offset(-1, 0).value

# 조건부 서식
rng = ws.range('C3:C8')

for cell in rng:
    if cell.value >= 10:
        cell.color = (255, 0, 0)

# E3~F8 중에 값이 5이하인 셀을 빨간색으로 변경
rng = ws.range('E3:F8')

for row in rng:
    for cell in row:
        if cell.value == None:
            print('None ---')
            pass
        elif cell.value <= 5:
            cell.color = (255, 0, 0)

wb.save('사무직 교육이수현황.xlsx')
xw.apps.active.quit()

# end
