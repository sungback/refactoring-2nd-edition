import xlwings as xw

wb = xw.Book('annual_leave_data/부서원 휴가사용조회-2023.09.xlsx')
ws = wb.sheets['Sheet1']
ws

# 범위를 복사
ws.range('I3:J8').copy()

wb2 = xw.Book('annual_leave_data/사무직 휴가사용현황(연구개발팀, 9월).xlsx')
ws2 = wb2.sheets['Sheet1']

# 값만 붙여넣기
ws2.range('I6').paste(paste='values')

# 서식, 함수 유지하고 붙여넣기
ws2.range('I6').paste()

# 가로로 붙여넣기
ws2.range('C15').paste(transpose=True)

# 3행 복사하기
ws.range('3:3').copy()

# B열 복사하기
ws.range('B:B').copy()

# C열 복사하기
ws.range('B:B').offset(0, 1).copy()

xw.apps.active.quit()

# paste 옵션
# all_merging_conditional_formats,
# all,
# all_except_borders,
# all_using_source_theme,
# column_widths,
# comments,
# formats,
# formulas,
# formulas_and_number_formats,
# validation,
# values,
# values_and_number_formats

# end
