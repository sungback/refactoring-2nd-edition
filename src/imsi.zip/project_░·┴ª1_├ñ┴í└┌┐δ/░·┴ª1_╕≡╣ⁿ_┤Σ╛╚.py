#!/usr/bin/env python
# coding: utf-8

# In[1]:


import warnings
warnings.filterwarnings('ignore')


# In[2]:


import pandas as pd
import xlwings as xw


# In[ ]:





# In[3]:


# 미션 1 정답


# In[4]:


in_folder = './input_dir/'
excel_file = in_folder + '상반기_제품_판매량_임꺽정.xlsx'


# In[5]:


wb = xw.Book(excel_file)
ws = wb.sheets['Sheet1']
df = ws.range('A1').options(pd.DataFrame, expand='table', index=False).value
df


# In[6]:


df['합계'] = df.sum(axis=1, numeric_only=True)
df


# In[7]:


out_folder = './output_dir/'
excel_file = out_folder + 'result1.xlsx'
df.to_excel(excel_file, index=False)
print("생성 파일:", excel_file)
xw.apps.active.quit()


# In[ ]:





# In[8]:


# 미션 2 정답


# In[9]:


from glob import glob


# In[10]:


in_folder = './input_dir/'
excel_files = glob(in_folder + '상반기_제품_판매량_*')
for excel_file in excel_files:
    print(excel_file)


# In[11]:


df_total = pd.DataFrame()
for excel_file in excel_files:
    wb = xw.Book(excel_file)
    ws = wb.sheets['Sheet1']
    df1 = ws.range('A1').options(pd.DataFrame, expand='table', index=False).value
    df_total = df_total.append(df1, ignore_index=True)
df_total


# In[12]:


out_folder = './output_dir/'
merged_file = out_folder + 'result2.xlsx'
df_total.to_excel(merged_file, index=False)
print("생성 파일:", merged_file)
xw.apps.active.quit()


# In[ ]:





# In[13]:


# 미션 3 정답


# In[14]:


excel_file = out_folder + 'result2.xlsx'
wb = xw.Book(excel_file)
ws = wb.sheets['Sheet1']
df = ws.range('A1').options(pd.DataFrame, expand='table', index=False).value
df


# In[15]:


cols = [ '1월', '2월', '3월', '4월', '5월', '6월' ]
df['상반기합계'] = df[ cols ].sum(axis=1)
df


# In[16]:


df2 = df[df['제품명'] == '스마트폰']
df2


# In[17]:


df3 = df2.reset_index(drop=True)
df3


# In[18]:


# 행방향 합계는 명령어 한 줄로는 안되고 약간의 단순 코드가 필요함!
series_sum1 = pd.Series({ '제품명':'스마트폰', '담당자':'전체', '지역':'전체' })
series_sum1


# In[19]:


series_sum2 = df3[ cols ].sum()
series_sum2


# In[20]:


series_sum3 = pd.concat([series_sum1, series_sum2])
series_sum3


# In[21]:


df4 = df3.append(series_sum3, ignore_index=True)
df4


# In[22]:


merged_file2 = out_folder + 'result3.xlsx'
df4.to_excel(merged_file2, index=False)
print("생성 파일:", merged_file2)
xw.apps.active.quit()


# In[23]:


# end

