#!/usr/bin/env python
# coding: utf-8

# In[1]:


import xlwings as xw
from glob import glob

in_folder = './in_dir/'
excel_files = glob(in_folder + 's*.xlsx') # sale001.xlsx, sale002.xlsx
my_book = xw.Book()
my_ws = my_book.sheets['Sheet1']
cnt = 1
for excel_file in excel_files:
    wb_temp = xw.Book(excel_file)
    for ws1 in wb_temp.sheets:
        for i in range(9, 19):
            if ws1.range(i, 2).value != None:
                my_ws.range(cnt, 1).value = ws1.range('G2').value  # 전표NO
                my_ws.range(cnt, 2).value = ws1.range('G3').value  # 일시
                my_ws.range(cnt, 3).value = ws1.range('C4').value  # 거래처 코드
                my_ws.range(cnt, 4).value = ws1.range('H7').value  # 담당자 코드
                my_ws.range(cnt, 5).value = ws1.range(i, 1).value  # No
                my_ws.range(cnt, 6).value = ws1.range(i, 2).value  # 상품 코드
                my_ws.range(cnt, 7).value = ws1.range(i, 3).value  # 품명
                my_ws.range(cnt, 8).value = ws1.range(i, 4).value  # 수량
                my_ws.range(cnt, 9).value = ws1.range(i, 5).value  # 단가
                my_ws.range(cnt, 10).value = ws1.range(i, 6).value # 금액
                my_ws.range(cnt, 11).value = ws1.range(i, 7).value # 비고
                cnt = cnt + 1
my_ws.autofit(axis="columns") # 컬럼 크기 자동으로 맞추기
my_book.save("./out_dir/result.xlsx")
xw.apps.active.quit()


# In[ ]:




# 참고로 openpyxl 과 pandas 로 처리한 코드
import pathlib
import openpyxl

try:
    lwb = openpyxl.Workbook()
    lsh = lwb.active
    list_row = 1
    path = pathlib.Path("./in_dir/")
    for pass_obj in path.iterdir():
        if pass_obj.match("*.xlsx"):
            wb = openpyxl.load_workbook(pass_obj)
            for sh in wb:
                for dt_row in range(9, 19):
                    if sh.cell(dt_row, 2).value != None:
                        lsh.cell(list_row, 1).value = sh['G2'].value  #전표NO
                        lsh.cell(list_row, 2).value = sh['G3'].value  #일시
                        lsh.cell(list_row, 3).value = sh['C4'].value  #거래처 코드
                        lsh.cell(list_row, 4).value = sh['H7'].value  #담당자 코드
                        lsh.cell(list_row, 5).value = sh.cell(dt_row, 1).value  #No
                        lsh.cell(list_row, 6).value = sh.cell(dt_row, 2).value  #상품 코드
                        lsh.cell(list_row, 7).value = sh.cell(dt_row, 3).value  #품명
                        lsh.cell(list_row, 8).value = sh.cell(dt_row, 4).value  #수량
                        lsh.cell(list_row, 9).value = sh.cell(dt_row, 5).value  #단가
                        lsh.cell(list_row, 10).value = sh.cell(dt_row, 4).value * sh.cell(dt_row, 5).value #금액
                        lsh.cell(list_row, 11).value = sh.cell(dt_row, 7).value  #비고
                        list_row += 1
    lwb.save("./out_dir/result.xlsx")
except Exception as e:
    print(e)
# In[2]:


# end

